# Panduan singkat
1. Letakkan model Blender yang diekspor sebagai models/avanta.glb.
2. Buka index.html lewat server lokal (python -m http.server 8000), lalu buka http://localhost:8000
3. Sesuaikan pos dan orbit tiap komponen di app.js agar hotspot pas di model.
4. Publikasikan gratis di GitHub Pages, Netlify, atau Cloudflare Pages (unggah seluruh folder).
