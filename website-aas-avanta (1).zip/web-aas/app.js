// Daftar komponen. Ubah posisi hotspot (pos) dan kamera (orbit) setelah model GLB kamu siap.
const K=[
{n:"Lampu katoda berongga",f:"Sumber cahaya khas unsur yang dianalisis (Ca: 422,7 nm).",pos:"0 0.4 0.3",orbit:"20deg 70deg 1.5m"},
{n:"Nebulizer",f:"Mengubah cairan sampel menjadi kabut halus.",pos:"0.3 0.1 0.2",orbit:"60deg 75deg 1.2m"},
{n:"Spray chamber",f:"Memilih tetesan halus dan mencampurnya dengan gas.",pos:"0.2 0 0.1",orbit:"80deg 75deg 1.2m"},
{n:"Burner head",f:"Tempat nyala. Atom bebas terbentuk di sini.",pos:"0 0.2 0",orbit:"0deg 60deg 1m"},
{n:"Monokromator",f:"Memilih panjang gelombang yang dipakai.",pos:"-0.2 0.2 0",orbit:"-40deg 75deg 1.4m"},
{n:"Detektor (PMT)",f:"Mengubah cahaya yang lolos menjadi sinyal listrik.",pos:"-0.4 0.2 0",orbit:"-70deg 75deg 1.4m"},
{n:"Kontrol gas dan drain",f:"Mengatur aliran gas dan membuang limbah cair.",pos:"0.1 -0.2 0.3",orbit:"30deg 90deg 1.4m"},
{n:"Komputer dan perangkat lunak",f:"Mengatur alat dan merekam absorbansi.",pos:"0.5 0 0",orbit:"90deg 80deg 2m"}
];
const mv=document.getElementById("mv"),ul=document.getElementById("daftar"),info=document.getElementById("info");
K.forEach((k,i)=>{
 const li=document.createElement("li");li.textContent=k.n;li.onclick=()=>pilih(i);ul.appendChild(li);
 const b=document.createElement("button");b.className="hs";b.slot="hotspot-"+i;b.textContent=i+1;
 b.setAttribute("data-position",k.pos);b.setAttribute("data-normal","0 1 0");b.setAttribute("aria-label",k.n);
 b.onclick=()=>pilih(i);mv.appendChild(b);
});
function pilih(i){
 const k=K[i];mv.removeAttribute("auto-rotate");mv.cameraOrbit=k.orbit;
 info.innerHTML="<b>"+k.n+"</b><p>"+k.f+"</p>";
 [...ul.children].forEach((l,j)=>l.classList.toggle("on",j===i));
}
function alur(){
 const urut=[1,2,3,4,5,7];let j=0;
 const t=document.getElementById("alurtxt");
 const id=setInterval(()=>{ if(j>=urut.length){clearInterval(id);t.textContent="Selesai.";return}
  pilih(urut[j]);t.textContent="Langkah "+(j+1)+" dari "+urut.length+": "+K[urut[j]].n;j++},2200);
}
function sim(){
 const v=document.getElementById("skn").value,s=document.getElementById("skn");
 document.getElementById("bar").style.width=v+"%";
 document.getElementById("simtxt").textContent="Sinyal Ca relatif: "+v+"% dari kondisi tanpa gangguan.";
}
sim();
